# tic-tac-toe
**Tic Tac Toe game using C++.**:video_game: Tested with Borland C++ 3.0 compiler.

Please change the last arguement to **initgraph** function in Tic-tac-toe.CPP
Watch the comment next to initgraph funtion for more information

The .exe (executable) file provided in here is 16bit exe file. This file may not be able to run directly on your PC without using DosBox like applications
